<?php
	define('FROM_MAIL', 'mail@developer-syful.com');
	 define('PASS', 'saif5683@');

    //define('FROM_MAIL', 'saifulislamw60@gmail.com');
	//define('PASS', 'SAIFULislam$25');
	
	
?>