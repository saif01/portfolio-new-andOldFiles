   <div class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
                    <p>&copy; All Right Reserved By <a href="" target="_blank">@saif</a></p> <!--edit here-->
                </div>
            </div>
        </div>
    </div>